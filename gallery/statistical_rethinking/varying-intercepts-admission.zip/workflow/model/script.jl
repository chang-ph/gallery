using StableRNGs
using AbstractMCMC

flow = Coinfer.current_workflow()
m = flow.model(flow.parsed_data...)

parallel_algorithm = Meta.parse(flow.settings["sampling"]["parallel_algorithm"]) |> eval
iteration_count = flow.settings["sampling"]["iteration_count"]
num_chains = flow.settings["sampling"]["num_chains"]

Coinfer.sample(
    StableRNG(Int(floor(time()))),
    m,
    NUTS(),
    parallel_algorithm,
    iteration_count,
    num_chains;
)